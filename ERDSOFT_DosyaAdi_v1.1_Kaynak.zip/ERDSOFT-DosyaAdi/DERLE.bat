@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
if errorlevel 1 (
    echo.
    echo Derleme hata verdi. Ayrintilar yukarida.
    pause
    exit /b 1
)
exit /b 0
