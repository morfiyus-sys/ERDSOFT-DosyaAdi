# ERDSOFT DosyaAdi v1.1 - Windows 11 x64 one-click portable EXE build
# Run with: powershell -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
param(
    [switch]$SkipPause
)

$ErrorActionPreference = 'Stop'
$projectPath = Join-Path $PSScriptRoot 'ERDSOFT.DosyaAdi.csproj'
$outputPath = Join-Path $PSScriptRoot 'dist'

try {
    Write-Host ''
    Write-Host 'ERDSOFT DosyaAdi v1.1 - Windows 11 Portable EXE' -ForegroundColor Cyan
    Write-Host '========================================='

    # Installation checks precede the build: no packages are auto-installed.
    $dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
    if (-not $dotnet) {
        throw '.NET 8 SDK bulunamadi. https://dotnet.microsoft.com/download/dotnet/8.0 adresinden SDK x64 kurun.'
    }

    $sdkList = @(& dotnet --list-sdks)
    if (-not ($sdkList | Where-Object { $_ -match '^8\.' })) {
        throw '.NET 8 SDK gerekli. Mevcut SDK listesi: ' + ($sdkList -join ', ')
    }

    Write-Host '.NET 8 SDK bulundu.' -ForegroundColor Green
    Write-Host 'Portable EXE derleniyor (win-x64)...'

    & dotnet publish $projectPath `
        --configuration Release `
        --runtime win-x64 `
        --self-contained true `
        --output $outputPath `
        -p:PublishSingleFile=true `
        -p:PublishTrimmed=false `
        -p:DebugType=none `
        -p:DebugSymbols=false `
        -p:GenerateDocumentationFile=false

    if ($LASTEXITCODE -ne 0) {
        throw 'Derleme basarisiz oldu; yukaridaki hatalari inceleyin.'
    }

    $compiledExe = Join-Path $outputPath 'ERDSOFT.DosyaAdi.exe'
    if (-not (Test-Path -LiteralPath $compiledExe -PathType Leaf)) {
        throw 'Derleme tamamlandi fakat beklenen EXE bulunamadi.'
    }

    Write-Host ''
    Write-Host 'BASARILI!' -ForegroundColor Green
    Write-Host ('EXE: ' + $compiledExe) -ForegroundColor Cyan
    Write-Host 'Bu EXE icin hedef bilgisayarda .NET kurulu olmasi gerekmez.'
    Write-Host 'Win11 icin dosyaya cift tiklayarak calistirabilirsiniz.'
}
catch {
    Write-Host ''
    Write-Host ('HATA: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
finally {
    if (-not $SkipPause -and $Host.Name -eq 'ConsoleHost') {
        Write-Host ''
        Read-Host 'Pencereyi kapatmak icin Enter tusuna basin' | Out-Null
    }
}
