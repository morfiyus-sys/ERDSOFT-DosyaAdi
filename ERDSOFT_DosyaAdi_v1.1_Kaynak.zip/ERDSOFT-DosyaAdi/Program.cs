using System.Threading;
using System.Windows.Forms;

namespace ERDSOFT.DosyaAdi;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        using var mutex = new Mutex(initiallyOwned: true, name: @"Local\ERDSOFT_DosyaAdi", out bool firstInstance);
        if (!firstInstance)
        {
            MessageBox.Show(
                "ERDSOFT DosyaAdı zaten çalışıyor. Saatin yanındaki simgeyi kontrol edin.",
                "ERDSOFT DosyaAdı", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        try
        {
            using var app = new DosyaAdiContext();
            Application.Run(app);
        }
        catch (Exception ex)
        {
            MessageBox.Show("Uygulama başlatılamadı:\n" + ex.Message,
                "ERDSOFT DosyaAdı", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        GC.KeepAlive(mutex);
    }
}
