using System.Text;
using System.Text.RegularExpressions;

namespace ERDSOFT.DosyaAdi;

/// <summary>
/// Reads the filename already shown in a standard Windows Open/Save file picker.
/// Does not send F2, Esc, Enter, or change the filename field's contents.
/// </summary>
internal static class FileDialogSelection
{
    private const int FilenameControlId = 0x047C; // cmb13 / modern file-name host (1148)
    private const int LegacyFilenameEditId = 0x0480; // edt1 (1152)
    private const uint WmGetText = 0x000D;
    private const uint SmtoAbortIfHung = 0x0002;

    public static bool IsFilePickerWindow(nint window)
    {
        if (GetClass(window) != "#32770") return false;
        // Called inside a low-level keyboard hook: never send cross-process
        // messages or wait for another application at this point.
        return FindFilenameControl(window, preferPopulated: false) != 0;
    }

    public static string GetSingleName(nint dialog)
    {
        if (GetClass(dialog) != "#32770")
            throw new InvalidOperationException("Bu pencere Windows dosya seçme penceresi değil.");

        nint control = FindFilenameControl(dialog, preferPopulated: true);
        if (control == 0)
            throw new InvalidOperationException("Dosya adı kutusu bulunamadı.");

        string raw = ReadText(control).Trim();
        if (string.IsNullOrWhiteSpace(raw))
            throw new InvalidOperationException("Önce listeden tek bir dosya seçin.");

        return NormalizeFilename(raw);
    }

    // The Windows Common Item Dialog includes nested ComboBoxEx32, ComboBox and
    // Edit controls, often each with the ID 1148. We search all descendants,
    // since the direct child layout differs between Windows builds/apps.
    private static nint FindFilenameControl(nint dialog, bool preferPopulated)
    {
        var candidates = new List<(nint Handle, int Priority)>();
        NativeMethods.EnumChildWindowsProc callback = (child, _) =>
        {
            int id = NativeMethods.GetDlgCtrlID(child);
            if (id is not (FilenameControlId or LegacyFilenameEditId)) return true;

            string cls = GetClass(child);
            int priority = cls switch
            {
                "Edit" => 40,
                "ComboBox" => 30,
                "ComboBoxEx32" => 20,
                _ => 0
            };
            if (priority > 0)
                candidates.Add((child, priority + (id == FilenameControlId ? 10 : 0)));
            return true;
        };

        NativeMethods.EnumChildWindows(dialog, callback, 0);
        if (candidates.Count == 0) return 0;

        if (!preferPopulated)
            return candidates.OrderByDescending(c => c.Priority).First().Handle;

        // Prefer the actual edit child with text. Some combo-box hosts respond
        // to WM_GETTEXT only when the edit child has focus.
        foreach (var candidate in candidates.OrderByDescending(c => c.Priority))
        {
            if (!string.IsNullOrWhiteSpace(ReadText(candidate.Handle)))
                return candidate.Handle;
        }

        return candidates.OrderByDescending(c => c.Priority).First().Handle;
    }

    private static string ReadText(nint control)
    {
        var buffer = new StringBuilder(4096);
        nint ok = NativeMethods.SendMessageTimeoutW(
            control, WmGetText, buffer.Capacity, buffer,
            SmtoAbortIfHung, 150, out nint charCount);

        return ok != 0 && charCount > 0 ? buffer.ToString() : "";
    }

    private static string GetClass(nint window)
    {
        var cls = new StringBuilder(128);
        return NativeMethods.GetClassNameW(window, cls, cls.Capacity) > 0 ? cls.ToString() : "";
    }

    internal static string NormalizeFilename(string raw)
    {
        string name = raw.Trim();
        if (name.Length == 0)
            throw new InvalidOperationException("Bir dosya seçilmedi.");

        // With multi-selection the Windows filename field contains names such
        // as: "one.pdf" "two.pdf". We deliberately reject that case.
        if (name.StartsWith('"'))
        {
            MatchCollection quotedNames = Regex.Matches(name, "\"([^\"]+)\"");
            if (quotedNames.Count != 1 || name != quotedNames[0].Value)
                throw new InvalidOperationException("Birden fazla öğe seçilmiş. Yalnızca bir dosya seçin.");
            name = quotedNames[0].Groups[1].Value;
        }

        if (name.IndexOfAny(new[] { '\r', '\n', '\0' }) >= 0)
            throw new InvalidOperationException("Geçersiz dosya adı.");

        string leaf = Path.GetFileName(name);
        if (string.IsNullOrWhiteSpace(leaf))
            throw new InvalidOperationException("Geçerli bir dosya adı bulunamadı.");

        return ExplorerSelection.WithoutExtension(leaf);
    }
}
