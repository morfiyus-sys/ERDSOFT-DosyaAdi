using System.Runtime.InteropServices;
using System.Text;

namespace ERDSOFT.DosyaAdi;

internal static class NativeMethods
{
    internal const int WhKeyboardLl = 13;
    internal const int WmKeyDown = 0x0100;
    internal const int WmKeyUp = 0x0101;
    internal const int WmSysKeyDown = 0x0104;
    internal const int WmSysKeyUp = 0x0105;
    internal const int VkF3 = 0x72;
    internal const int VkF4 = 0x73;
    internal const int VkControl = 0x11;
    internal const int VkShift = 0x10;
    internal const int VkMenu = 0x12;
    internal const int VkLwin = 0x5B;
    internal const int VkRwin = 0x5C;
    internal const uint LlkhfInjected = 0x10;
    private const uint InputKeyboard = 1;
    private const uint KeyeventfKeyup = 2;

    [StructLayout(LayoutKind.Sequential)]
    internal struct KbdLlHookStruct
    {
        internal uint vkCode;
        internal uint scanCode;
        internal uint flags;
        internal uint time;
        internal UIntPtr dwExtraInfo;
    }

    // INPUT has a 32-byte union on x64; explicit size prevents a bad cbSize.
    [StructLayout(LayoutKind.Sequential)]
    private struct Input
    {
        internal uint type;
        internal InputUnion union;
    }

    [StructLayout(LayoutKind.Explicit, Size = 32)]
    private struct InputUnion
    {
        [FieldOffset(0)] internal KeybdInput ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KeybdInput
    {
        internal ushort wVk;
        internal ushort wScan;
        internal uint dwFlags;
        internal uint time;
        internal UIntPtr dwExtraInfo;
    }

    internal delegate nint LowLevelKeyboardProc(int nCode, nint wParam, nint lParam);

    [DllImport("user32.dll", SetLastError = true)]
    internal static extern nint SetWindowsHookExW(int idHook, LowLevelKeyboardProc callback, nint module, uint threadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool UnhookWindowsHookEx(nint hook);

    [DllImport("user32.dll")]
    internal static extern nint CallNextHookEx(nint hook, int code, nint wParam, nint lParam);

    [DllImport("user32.dll")]
    internal static extern nint GetForegroundWindow();

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    internal static extern int GetClassNameW(nint hwnd, StringBuilder className, int maxCount);

    [DllImport("user32.dll", SetLastError = true)]
    internal static extern int GetDlgCtrlID(nint hwnd);

    internal delegate bool EnumChildWindowsProc(nint child, nint lParam);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool EnumChildWindows(nint parent, EnumChildWindowsProc callback, nint lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    internal static extern nint SendMessageTimeoutW(
        nint hwnd, uint message, nint wParam, StringBuilder textBuffer,
        uint flags, uint timeoutMillis, out nint result);

    [DllImport("user32.dll")]
    internal static extern short GetAsyncKeyState(int virtualKey);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    internal static extern nint GetModuleHandleW(string? moduleName);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(uint count, [In] Input[] inputs, int size);

    internal static bool IsModifierDown()
    {
        foreach (int key in new[] { VkControl, VkShift, VkMenu, VkLwin, VkRwin })
        {
            if ((GetAsyncKeyState(key) & 0x8000) != 0) return true;
        }
        return false;
    }

    internal static bool IsExplorerForeground()
    {
        var buffer = new StringBuilder(256);
        nint hwnd = GetForegroundWindow();
        return hwnd != 0 && GetClassNameW(hwnd, buffer, buffer.Capacity) > 0
            && string.Equals(buffer.ToString(), "CabinetWClass", StringComparison.Ordinal);
    }

    internal static bool SendPaste()
    {
        static Input Key(ushort vk, bool up) => new()
        {
            type = InputKeyboard,
            union = new InputUnion
            {
                ki = new KeybdInput { wVk = vk, dwFlags = up ? KeyeventfKeyup : 0 }
            }
        };

        Input[] inputs =
        {
            Key(VkControl, false), Key((ushort)'V', false),
            Key((ushort)'V', true), Key(VkControl, true)
        };
        return SendInput((uint)inputs.Length, inputs, Marshal.SizeOf<Input>()) == inputs.Length;
    }
}
