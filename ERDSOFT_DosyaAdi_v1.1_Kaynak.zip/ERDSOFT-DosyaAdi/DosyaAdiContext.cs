using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.Win32;

namespace ERDSOFT.DosyaAdi;

internal sealed class DosyaAdiContext : ApplicationContext
{
    private const string StartupRegistryPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string StartupRegistryValue = "ERDSOFT_DosyaAdi";

    private readonly Control _invoker = new();
    private readonly NotifyIcon _tray;
    private readonly ToolStripMenuItem _lastNameMenuItem;
    private readonly ToolStripMenuItem _startupMenuItem;
    private readonly NativeMethods.LowLevelKeyboardProc _hookDelegate;
    private nint _hook;
    private string? _savedName;
    private bool _f3Down;
    private bool _f4Down;
    private bool _disposed;

    public DosyaAdiContext()
    {
        // A handle is required for BeginInvoke from the hook. Both run on the UI STA.
        _ = _invoker.Handle;
        _lastNameMenuItem = new ToolStripMenuItem("Henüz dosya adı kopyalanmadı") { Enabled = false };
        _startupMenuItem = new ToolStripMenuItem("Windows ile başlat")
        {
            Checked = IsStartupEnabled(),
            CheckOnClick = false
        };
        _startupMenuItem.Click += (_, _) => ToggleStartup();

        var menu = new ContextMenuStrip();
        menu.Items.Add(new ToolStripMenuItem("ERDSOFT DosyaAdı v1.1") { Enabled = false });
        menu.Items.Add(_lastNameMenuItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(new ToolStripMenuItem("Kullanım bilgisi", null, (_, _) => ShowHelp()));
        menu.Items.Add(_startupMenuItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(new ToolStripMenuItem("Çıkış", null, (_, _) => ExitThread()));

        _tray = new NotifyIcon
        {
            Icon = System.Drawing.SystemIcons.Application,
            Text = "ERDSOFT DosyaAdı — F3 kopyala, F4 yapıştır",
            ContextMenuStrip = menu,
            Visible = true
        };
        _tray.DoubleClick += (_, _) => ShowHelp();

        _hookDelegate = KeyboardHook;
        _hook = NativeMethods.SetWindowsHookExW(
            NativeMethods.WhKeyboardLl, _hookDelegate,
            NativeMethods.GetModuleHandleW(null), 0);
        if (_hook == 0)
        {
            _tray.Dispose();
            _invoker.Dispose();
            throw new Win32Exception(Marshal.GetLastWin32Error(),
                "Klavye kısayolları başlatılamadı.");
        }
    }

    private nint KeyboardHook(int code, nint wParam, nint lParam)
    {
        try { return ProcessKeyboardHook(code, wParam, lParam); }
        catch { return NativeMethods.CallNextHookEx(_hook, code, wParam, lParam); }
    }

    private nint ProcessKeyboardHook(int code, nint wParam, nint lParam)
    {
        if (code < 0 || _disposed)
            return NativeMethods.CallNextHookEx(_hook, code, wParam, lParam);

        var keyboard = Marshal.PtrToStructure<NativeMethods.KbdLlHookStruct>(lParam);
        if ((keyboard.flags & NativeMethods.LlkhfInjected) != 0)
            return NativeMethods.CallNextHookEx(_hook, code, wParam, lParam);

        bool isDown = wParam == NativeMethods.WmKeyDown || wParam == NativeMethods.WmSysKeyDown;
        bool isUp = wParam == NativeMethods.WmKeyUp || wParam == NativeMethods.WmSysKeyUp;
        if (!isDown && !isUp)
            return NativeMethods.CallNextHookEx(_hook, code, wParam, lParam);

        if (keyboard.vkCode == NativeMethods.VkF3)
        {
            if (isUp && _f3Down) { _f3Down = false; return 1; }
            if (isDown && _f3Down) return 1;
            if (isDown && !NativeMethods.IsModifierDown())
            {
                nint activeWindow = NativeMethods.GetForegroundWindow();
                bool isExplorer = NativeMethods.IsExplorerForeground();
                bool isPicker = !isExplorer && FileDialogSelection.IsFilePickerWindow(activeWindow);
                if (isExplorer || isPicker)
                {
                    _f3Down = true;
                    _invoker.BeginInvoke(new Action(() => CaptureName(activeWindow, isPicker)));
                    return 1;
                }
            }
        }
        else if (keyboard.vkCode == NativeMethods.VkF4)
        {
            if (isUp && _f4Down) { _f4Down = false; return 1; }
            if (isDown && _f4Down) return 1;
            if (isDown && !NativeMethods.IsModifierDown() && !string.IsNullOrEmpty(_savedName))
            {
                _f4Down = true;
                _invoker.BeginInvoke(new Action(PasteName));
                return 1;
            }
        }
        return NativeMethods.CallNextHookEx(_hook, code, wParam, lParam);
    }

    private void CaptureName(nint activeWindow, bool isFilePicker)
    {
        try
        {
            string name = isFilePicker
                ? FileDialogSelection.GetSingleName(activeWindow)
                : ExplorerSelection.GetSingleName(activeWindow);
            SetClipboardText(name);
            _savedName = name;
            _lastNameMenuItem.Text = name.Length > 60 ? name[..57] + "..." : name;
            Notify("Dosya adı kopyalandı", name, ToolTipIcon.Info);
        }
        catch (Exception ex)
        {
            // Never paste a previous filename after the user attempted a new selection.
            _savedName = null;
            _lastNameMenuItem.Text = "Henüz geçerli dosya adı yok";
            Notify("Dosya adı alınamadı", ex.Message, ToolTipIcon.Warning);
        }
    }

    private void PasteName()
    {
        if (string.IsNullOrEmpty(_savedName)) return;
        try
        {
            // Restore our saved filename even if another app changed the clipboard.
            SetClipboardText(_savedName);
            if (!NativeMethods.SendPaste())
                Notify("Yapıştırma başarısız", "Ctrl+V gönderilemedi.", ToolTipIcon.Warning);
        }
        catch (Exception ex)
        {
            Notify("Yapıştırma başarısız", ex.Message, ToolTipIcon.Warning);
        }
    }

    private void Notify(string title, string message, ToolTipIcon icon)
    {
        // Windows 11 might deliver this in Notification Center rather than a balloon.
        _tray.BalloonTipTitle = title;
        _tray.BalloonTipText = message;
        _tray.BalloonTipIcon = icon;
        _tray.ShowBalloonTip(1100);
    }

    private static void SetClipboardText(string text)
    {
        // Clipboard access can be temporarily locked by Excel/Word/other apps.
        for (int attempt = 0; ; attempt++)
        {
            try
            {
                Clipboard.SetText(text, TextDataFormat.UnicodeText);
                return;
            }
            catch (ExternalException) when (attempt < 3)
            {
                Thread.Sleep(40);
            }
        }
    }

    private void ShowHelp() => MessageBox.Show(
        "F3: Dosya Gezgini'nde veya Windows Aç/Farklı Kaydet penceresinde seçili tek dosyanın uzantısız adını kopyalar.\n\n" +
        "F4: Kopyalanan adı Word, Excel, Chrome veya başka bir metin alanına yapıştırır.\n\n" +
        "F3 yalnızca desteklenen dosya pencerelerinde çalışır. Alt+F4 ve diğer değiştiricili tuşlar korunur.\n\n" +
        "İpucu: Uygulamadan çıkmak için saat yanındaki ERDSOFT simgesine sağ tıklayın.",
        "ERDSOFT DosyaAdı", MessageBoxButtons.OK, MessageBoxIcon.Information);

    private static bool IsStartupEnabled()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(StartupRegistryPath);
            return key?.GetValue(StartupRegistryValue) is string;
        }
        catch { return false; }
    }

    private void ToggleStartup()
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey(StartupRegistryPath);
            if (_startupMenuItem.Checked)
                key?.DeleteValue(StartupRegistryValue, throwOnMissingValue: false);
            else
                key?.SetValue(StartupRegistryValue, "\"" + Application.ExecutablePath + "\"");
            _startupMenuItem.Checked = IsStartupEnabled();
        }
        catch (Exception ex)
        {
            Notify("Başlangıç ayarı değiştirilemedi", ex.Message, ToolTipIcon.Warning);
        }
    }

    protected override void ExitThreadCore()
    {
        if (_disposed) return;
        _disposed = true;
        if (_hook != 0) NativeMethods.UnhookWindowsHookEx(_hook);
        _hook = 0;
        _tray.Visible = false;
        _tray.ContextMenuStrip?.Dispose();
        _tray.Dispose();
        _invoker.Dispose();
        base.ExitThreadCore();
    }
}
