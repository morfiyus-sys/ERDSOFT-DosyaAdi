# ERDSOFT DosyaAdı v1.1

Windows 11 için **ücretsiz, açık kaynak kodlu, MIT lisanslı, tek EXE olarak dağıtılabilen** küçük klavye yardımcısı.

## Kullanım

1. Windows **Dosya Gezgini** içinde veya Chrome/Word/Excel gibi bir uygulamanın açtığı standart **Aç / Farklı Kaydet** dosya seçme penceresinde **tek** dosya seçin.
2. **F3**'e basın. Seçilen dosyanın **uzantısız adı** panoya ve uygulamanın kendi hafızasına alınır. Dosyaya dokunulmaz; yeniden adlandırma ekranı açılmaz.
3. Word, Excel, Chrome veya başka bir uygulamada yapıştırılacak yere tıklayın.
4. **F4**'e basın. Hafızadaki ad, etkin uygulamaya Ctrl+V ile yapıştırılır.

Örnek: `2026 HAKEDIS RAPORU.pdf` → `2026 HAKEDIS RAPORU`.

Türkçe karakterleri ve boşlukları korur. Tek klasör seçilirse klasörün tam adı alınır. Birden çok öğe seçilmişse işlem yapılmaz, uyarı gösterilir ve eski isim hafızadan temizlenir. F4 ancak geçerli bir isim alındıysa özel yapıştırma işlevi görür.

**v1.1 yeniliği:** İnternet sitelerindeki dosya yükleme düğmesiyle açılan Windows **Aç** penceresinde de F3 çalışır. Bu pencerede alttaki **Dosya adı** alanında görünen seçili dosya adını *salt okunur* şekilde okur; `F2`, `ESC`, `Enter` göndermez, dosyayı açmaz, yüklemeyi başlatmaz. Ardından `Aç` düğmesine basıp dosyayı seçmeye devam edebilirsiniz; kopyalanan ismi sonradan F4 ile istediğiniz metin alanına yapıştırabilirsiniz.

Saatin yanındaki uygulama simgesine sağ tıklayarak yardım, Windows ile başlatma veya çıkış seçeneklerini açabilirsiniz. Başlangıç seçeneği **varsayılan olarak kapalıdır**. Açıldığında yalnızca mevcut Windows kullanıcısına ait Run kaydı oluşturulur.

### Tuş çakışmaları

- **F3** sadece ön planda Dosya Gezgini veya desteklenen standart Windows dosya seçme penceresi varsa ele alınır. Explorer'ın F3 ile arama yapma kısayolu bu pencerede dosya adını kopyalar.
- **F4** daha önce geçerli ad alınmışsa tüm uygulamalarda dosya adı yapıştırır; Excel'in F4 ile son işlemi tekrarlama gibi yerleşik F4 davranışının yerini alır.
- **Alt+F4, Ctrl+F4, Shift+F4** gibi değiştiricili kombinasyonlara müdahale edilmez.
- Uygulama kapalıyken Windows tuşlarının normal işlevleri geri gelir.

## EXE oluşturma (Windows 11, x64)

**Gerekli:** Derleme yapılacak bilgisayarda `.NET 8 SDK x64` kurulu olmalı. Yalnızca Runtime yeterli değildir.

1. ZIP dosyasını bir klasöre çıkarın.
2. `DERLE.bat` dosyasını çift tıklayın (veya PowerShell'de `./build.ps1` çalıştırın).
3. Derleme başarılıysa `dist/ERDSOFT.DosyaAdi.exe` oluşturulur.
4. Bu dosyayı istediğiniz klasöre taşıyın ve çift tıklayarak çalıştırın.

EXE **self-contained** olarak oluşturulur: çalıştıracağınız diğer Windows bilgisayarlarında .NET SDK veya Runtime kurulu olması gerekmez. Uygulama ek NuGet paketi kullanmaz; Windows ve .NET 8'in standart özelliklerine dayanır.

Komut satırından eşdeğer derleme:

```powershell
dotnet publish .\ERDSOFT.DosyaAdi.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:PublishTrimmed=false -o .\dist
```

## Hızlı kontrol listesi

- [ ] `örnek.xlsx` seçiliyken F3'ten sonra pano `örnek` içeriyor.
- [ ] Chrome'da bir web formunda **Dosya seç** → Windows **Aç** penceresi → `örnek.xlsx` seç → F3 → pano `örnek` içeriyor; Aç penceresi kapanmıyor.
- [ ] Aynı işlemde `örnek.xlsx` dosyası açılmadan, taşınmadan, yeniden adlandırılmadan yerinde duruyor.
- [ ] İki dosya seçildiğinde F3 yalnızca uyarı veriyor; isimler birleştirilmiyor.
- [ ] Word'e tıklayıp F4 basınca `örnek` ekleniyor.
- [ ] Excel hücresine F4 ile metin yapıştırılıyor.
- [ ] Chrome metin kutusunda F4 çalışıyor.
- [ ] Dosyanın **adı, içeriği ve değiştirilme tarihi** aynı kalıyor.
- [ ] Birden fazla dosya seçilince uyarı çıkıyor ve önceki isim tekrar yapıştırılmıyor.
- [ ] Explorer dışında F3 normal çalışıyor; Alt+F4 pencere kapatıyor.
- [ ] Programdan çıkınca F3 ve F4 normal işlevlerine dönüyor.
- [ ] Windows ile başlatma tercihi açılıp kapatılabiliyor.

## Bilinen sınırlar

- Windows 11 x64 için tasarlanmıştır. Windows'un standart **Explorer** ve `#32770` sınıfındaki **Aç / Farklı Kaydet** pencerelerini kullanır. Başka dosya yöneticilerinin (Total Commander vb.) veya özel tasarlanmış üçüncü taraf seçicilerin seçimlerini okumaz.
- Standart dosya seçicide F3, seçilen dosyanın alttaki **Dosya adı** kutusuna yazılmış olmasına dayanır. Bazı uygulamalar bu alanı farklı biçimde uyguladığından hepsinde çalışması garanti değildir.
- Sanal Explorer öğeleri (ör. kontrol paneli simgeleri) dosya sayılmaz.
- Standart kullanıcı yetkisiyle çalışan uygulama, **yönetici olarak başlatılmış** hedef programlara güvenilir biçimde klavye olayı gönderemeyebilir. Bunun için Windows'un UIPI güvenlik sınırları geçerlidir.
- Ekran görüntüsü, tuş geçmişi, dosya içeriği veya ağ verisi toplamaz. Yalnızca F3 ve F4 tuş olaylarını izleyip istenen işlemi gerçekleştirir.
- Windows 11'in bazı bildirim ayarlarında uyarılar bildirim merkezine düşebilir.

## Kod yapısı

| Dosya | Görev |
| --- | --- |
| `Program.cs` | Tek örnek çalışma, uygulama başlangıcı |
| `DosyaAdiContext.cs` | F3/F4 kısayolları, simge, pano, yapıştırma, kullanıcı seçenekleri |
| `ExplorerSelection.cs` | Windows Shell COM ile seçili tek öğeyi dosyaya dokunmadan okuma |
| `FileDialogSelection.cs` | Windows Aç / Farklı Kaydet penceresinin dosya adı kutusunu salt okunur olarak okuma |
| `NativeMethods.cs` | Win32 klavye kancası ve Ctrl+V gönderimi |
| `build.ps1` / `DERLE.bat` | Windows'ta tek EXE oluşturma |

## Lisans

Kaynak kodu [MIT License](LICENSE) ile yayımlanabilir. .NET ve Windows API bileşenlerinin kendi lisansları ayrıca geçerlidir.
