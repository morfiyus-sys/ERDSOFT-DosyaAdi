using System.Globalization;
using System.Runtime.InteropServices;

namespace ERDSOFT.DosyaAdi;

internal static class ExplorerSelection
{
    // Returns exactly one selected file/folder name. Never enters rename mode
    // and never changes the file or the current Explorer selection.
    public static string GetSingleName(nint explorerWindow)
    {
        Type shellType = Type.GetTypeFromProgID("Shell.Application")
            ?? throw new InvalidOperationException("Windows Shell hizmeti kullanılamıyor.");

        object? shellObject = null;
        object? windowsObject = null;
        try
        {
            shellObject = Activator.CreateInstance(shellType)
                ?? throw new InvalidOperationException("Windows Shell başlatılamadı.");
            dynamic shell = shellObject;
            windowsObject = shell.Windows();
            dynamic windows = windowsObject;
            int windowCount = Convert.ToInt32(windows.Count, CultureInfo.InvariantCulture);

            for (int index = 0; index < windowCount; index++)
            {
                object? browserObject = null;
                object? documentObject = null;
                object? itemsObject = null;
                object? itemObject = null;
                try
                {
                    browserObject = windows.Item(index);
                    if (browserObject is null) continue;
                    dynamic browser = browserObject;
                    long browserHandle = Convert.ToInt64(browser.HWND, CultureInfo.InvariantCulture);
                    if (unchecked((uint)browserHandle) != unchecked((uint)explorerWindow.ToInt64()))
                        continue;

                    documentObject = browser.Document;
                    if (documentObject is null)
                        throw new InvalidOperationException("Explorer klasör görünümü okunamadı.");
                    dynamic document = documentObject;
                    itemsObject = document.SelectedItems();
                    dynamic items = itemsObject!;
                    int count = Convert.ToInt32(items.Count, CultureInfo.InvariantCulture);
                    if (count != 1)
                        throw new InvalidOperationException(count == 0
                            ? "Önce tek bir dosya seçin."
                            : "Birden fazla öğe seçilmiş. Yalnızca bir dosya seçin.");

                    itemObject = items.Item(0);
                    dynamic item = itemObject!;
                    string path = Convert.ToString(item.Path, CultureInfo.InvariantCulture) ?? "";
                    if (File.Exists(path))
                        return WithoutExtension(Path.GetFileName(path));
                    if (Directory.Exists(path))
                        return Path.GetFileName(Path.TrimEndingDirectorySeparator(path));

                    throw new InvalidOperationException(
                        "Seçilen öğe yerel bir dosya veya klasör değil.");
                }
                finally
                {
                    ReleaseCom(itemObject);
                    ReleaseCom(itemsObject);
                    ReleaseCom(documentObject);
                    ReleaseCom(browserObject);
                }
            }

            throw new InvalidOperationException("Etkin Dosya Gezgini penceresi okunamadı.");
        }
        finally
        {
            ReleaseCom(windowsObject);
            ReleaseCom(shellObject);
        }
    }

    internal static string WithoutExtension(string filename)
    {
        // Keep leading-dot names (e.g. '.gitignore') intact.
        int lastDot = filename.LastIndexOf('.');
        return lastDot > 0 ? filename[..lastDot] : filename;
    }

    private static void ReleaseCom(object? value)
    {
        if (value is not null && Marshal.IsComObject(value))
            Marshal.ReleaseComObject(value);
    }
}
