# Sürüm geçmişi

## 1.1.0 — 18 Kasım 2026

- **F3**, Dosya Gezgini'nin yanında Chrome, Word ve benzeri uygulamaların açtığı standart Windows **Aç / Farklı Kaydet** dosya seçme pencerelerinde de çalışır.
- Standart dosya seçme penceresinde dosya adı, alttaki **Dosya adı** kutusundan yalnızca okunur; F2, Escape veya Enter simülasyonu yapılmaz.
- Birden fazla dosya adına karşı koruma eklendi; uzantı kaldırma ve F4'te yapıştırma davranışı korundu.
- F3 yalnızca desteklenen dosya pencerelerinde ele alınır. Diğer uygulamalarda F3'ün normal işlevi korunur.

## 1.0.0 — 18 Kasım 2026

- Explorer'da tek dosya/klasör seçiliyken F3 ile uzantısız adı kopyalama.
- F4 ile Word, Excel, Chrome ve diğer uygulamalara yapıştırma.
- Sistem tepsisi menüsü, Windows ile otomatik başlatma tercihi, tek EXE oluşturma aracı.
